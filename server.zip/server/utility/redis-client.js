//@ts-check
'use-strict';
module.exports = require('redis').createClient();